import React from "react";
import { ShoppingBag, Store } from "lucide-react";
import { useStore } from "../../context/StoreContext";

export const CartChoiceModal: React.FC = () => {
  const { cartPromptProduct, confirmOpenCart, continueShopping, language } =
    useStore();

  if (!cartPromptProduct) return null;

  return (
    <div className="fixed inset-0 z-[80] flex items-end sm:items-center justify-center p-4">
      <button
        className="absolute inset-0 bg-slate-950/50"
        aria-label={language === "ar" ? "إغلاق" : "Close"}
        onClick={continueShopping}
      />
      <div className="relative w-full max-w-md rounded-3xl glass-card border border-white/10 p-5 shadow-2xl space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-emerald-600 text-white flex items-center justify-center">
            <ShoppingBag className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-black font-cairo">
              {language === "ar" ? "تمت إضافة المنتج إلى السلة" : "Added to cart"}
            </h3>
            <p className="text-xs text-slate-400">
              {language === "ar"
                ? cartPromptProduct.nameAr
                : cartPromptProduct.nameEn}
            </p>
          </div>
        </div>
        <p className="text-sm text-slate-400">
          {language === "ar"
            ? "هل تريد فتح السلة الآن أم متابعة التسوق؟"
            : "Open the cart now, or keep shopping?"}
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <button
            type="button"
            onClick={confirmOpenCart}
            className="min-h-11 rounded-xl bg-purple-600 text-white text-sm font-bold"
          >
            {language === "ar" ? "فتح السلة" : "Open cart"}
          </button>
          <button
            type="button"
            onClick={continueShopping}
            className="min-h-11 rounded-xl border border-white/10 glass-panel text-sm font-bold flex items-center justify-center gap-2"
          >
            <Store className="w-4 h-4" />
            {language === "ar" ? "متابعة التسوق" : "Continue shopping"}
          </button>
        </div>
      </div>
    </div>
  );
};
