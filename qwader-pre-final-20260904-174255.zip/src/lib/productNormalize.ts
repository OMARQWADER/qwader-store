import { Product } from "../types";
import { normalizeRole } from "../utils/roles";

export function normalizeProduct(product: any): Product {
  const priceJOD = Number(product?.priceJOD ?? product?.price_jod) || 0;
  const priceUSD = Number(product?.priceUSD ?? product?.price_usd) || 0;
  return {
    id: String(product?.id || ""),
    nameAr: product?.nameAr || product?.name_ar || "",
    nameEn: product?.nameEn || product?.name_en || "",
    category: product?.category || "games",
    priceJOD,
    priceUSD,
    originalPriceJOD: product?.originalPriceJOD,
    originalPriceUSD: product?.originalPriceUSD,
    rating: Number(product?.rating) || 5,
    reviewsCount: Number(product?.reviewsCount ?? product?.reviews_count) || 0,
    stockQuantity: Number(product?.stockQuantity ?? product?.stock_quantity) || 0,
    lowStockThreshold: Number(product?.lowStockThreshold) || 5,
    isFeatured: Boolean(product?.isFeatured),
    badgeAr: product?.badgeAr,
    badgeEn: product?.badgeEn,
    image: product?.image || "",
    platform: product?.platform || "PS4 & PS5",
    regionAr: product?.regionAr || "",
    regionEn: product?.regionEn || "",
    deliveryTypeAr: product?.deliveryTypeAr || "",
    deliveryTypeEn: product?.deliveryTypeEn || "",
    shortDescAr: product?.shortDescAr || product?.description_ar || "",
    shortDescEn: product?.shortDescEn || product?.description_en || "",
    descriptionAr: product?.descriptionAr || product?.description_ar || "",
    descriptionEn: product?.descriptionEn || product?.description_en || "",
    featuresAr: Array.isArray(product?.featuresAr) ? product.featuresAr : [],
    featuresEn: Array.isArray(product?.featuresEn) ? product.featuresEn : [],
    createdAt: product?.createdAt || product?.created_at || new Date().toISOString(),
  };
}

export function normalizeUserRecord(user: any) {
  if (!user) return user;
  return {
    ...user,
    role: normalizeRole(user.role),
    registeredAt:
      user.registeredAt || user.registered_at || new Date().toISOString(),
  };
}
