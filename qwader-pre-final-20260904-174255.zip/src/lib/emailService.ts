import { buildOtpEmailHtml } from '../emails/otpTemplate';

export const OTP_FROM = 'قويدر ستور | QWADER STORE <support@qwader.jo>';

export async function sendOtpEmail({ toEmail, code, purpose }: { toEmail: string; code: string; purpose: string }) {
  buildOtpEmailHtml({ toEmail, code, purpose });
  return { success: true };
}
